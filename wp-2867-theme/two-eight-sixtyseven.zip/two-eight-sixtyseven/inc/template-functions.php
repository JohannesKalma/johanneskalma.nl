<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package two-eight-sixtyseven
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function two_eight_sixtyseven_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'two_eight_sixtyseven_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function two_eight_sixtyseven_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'two_eight_sixtyseven_pingback_header' );


add_filter('get_the_archive_title_prefix','__return_false');


define('ALLOW_UNFILTERED_UPLOADS', true);

/*
add_filter( 'upload_mimes', function() {
  $mimes = [
    'tgz' => 'application/gzip',
  ];
  return $mimes;
});
*/

/* Reverse default date descending order for specific categories */
function two_eight_sixtyseven_change_category_order ($query) {
    //Sort all posts from category with id=19 (interviews) by date asc order
    if($query->is_category('76') && $query->is_main_query()){
//        $query->set( 'order', 'ASC' );
        $query->query_vars['orderby'] = 'date';
        $query->query_vars['order'] = 'ASC';
    }
}

add_action( 'pre_get_posts', 'two_eight_sixtyseven_change_category_order' );

