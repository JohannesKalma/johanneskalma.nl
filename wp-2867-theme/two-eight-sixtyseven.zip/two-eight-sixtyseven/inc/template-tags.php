<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package two-eight-sixtyseven
 */

if ( ! function_exists( 'two_eight_sixtyseven_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function two_eight_sixtyseven_posted_on() {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = sprintf(
			/* translators: %s: post date. */
			esc_html_x( '%s', 'post date', 'two-eight-sixtyseven' ),
			'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
		);

		echo '<span class="posted-on">' . $posted_on . '</span>'; // WPCS: XSS OK.

	}
endif;

if ( ! function_exists( 'two_eight_sixtyseven_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function two_eight_sixtyseven_posted_by() {
		$posted_by = sprintf(
			/* translators: %s: post author. */
			esc_html_x( ' %s', 'post author', 'two-eight-sixtyseven' ),
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);

		echo '<span class="byline"><i class="material-icons">person</i>' . $posted_by . '</span>'; // WPCS: XSS OK.

	}
endif;

if ( ! function_exists( 'two_eight_sixtyseven_categories_list' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function two_eight_sixtyseven_categories_list() {
		if ( 'post' === get_post_type() ) :
			/* translators: used between list items, there is a space after the comma */
			$categories_list = get_the_category_list( esc_html__( ', ', 'two-eight-sixtyseven' ) );
			if ( $categories_list ) :
				/* translators: 1: list of categories. */
				printf( '<span class="cat-links"><i class="material-icons">folder</i>' . esc_html__( ' %1$s', 'two-eight-sixtyseven' ) . '</span>', $categories_list ); // WPCS: XSS OK.
			endif;
	  endif;
	}
endif;

if ( ! function_exists( 'two_eight_sixtyseven_tags_list' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function two_eight_sixtyseven_tags_list() {
		if ( 'post' === get_post_type() ) :
		/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'two-eight-sixtyseven' ) );
			if ( $tags_list ) :
				/* translators: 1: list of tags. */
				printf( '<span class="tags-links"><i class="material-icons">bookmark</i>' . esc_html__( ' %1$s', 'two-eight-sixtyseven' ) . '</span>', $tags_list ); // WPCS: XSS OK.
			endif;
		endif;
	}
endif;

if ( ! function_exists( 'two_eight_sixtyseven_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function two_eight_sixtyseven_entry_footer() {

		two_eight_sixtyseven_posted_by();
		// Hide category and tag text for pages.
		//if ( 'post' === get_post_type() ) {
		//	/* translators: used between list items, there is a space after the comma */
	  //		$categories_list = get_the_category_list( esc_html__( ', ', 'two-eight-sixtyseven' ) );
		//	if ( $categories_list ) {
		//		/* translators: 1: list of categories. */
		//		printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s', 'two-eight-sixtyseven' ) . '</span>', $categories_list ); // WPCS: XSS OK.
		//	}
		two_eight_sixtyseven_categories_list();
		//	/* translators: used between list items, there is a space after the comma */
		//	$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'two-eight-sixtyseven' ) );
		//	if ( $tags_list ) {
		//		/* translators: 1: list of tags. */
		//		printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'two-eight-sixtyseven' ) . '</span>', $tags_list ); // WPCS: XSS OK.
		//	}
		//}
		two_eight_sixtyseven_tags_list();

		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			comments_popup_link(
				sprintf(
					wp_kses(
						/* translators: %s: post title */
						__( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'two-eight-sixtyseven' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					get_the_title()
				)
			);
			echo '</span>';
		}



		edit_post_link(
			sprintf('<i class="material-icons">edit</i>'.
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( '<span class="screen-reader-text">%s</span>', 'two-eight-sixtyseven' ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				get_the_title()
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
endif;

if ( ! function_exists( 'two_eight_sixtyseven_the_posts_navigation') ):
/* prints posts_navigation like wordpress get_the_posts_navigation
   extended with pagination information (1 of 3)
*/
  function two_eight_sixtyseven_the_posts_navigation( $args = array() ) {
		echo two_eight_sixtyseven_posts_navigation( $args );
	}

endif;

if ( ! function_exists( 'two_eight_sixtyseven_posts_navigation') ):
/* prints posts_navigation like wordpress get_the_posts_navigation
   extended with pagination information (1 of 3)
*/
  function two_eight_sixtyseven_posts_navigation( $args = array() ) {

	    $navigation = '';
      $total   = $GLOBALS['wp_query']->max_num_pages;

	    // Don't print empty markup if there's only one page.
	    if ( $total > 1 ) :
	        $args = wp_parse_args(
	            $args,
	            array(
	                'prev_text'          => __( 'Older posts' ),
	                'next_text'          => __( 'Newer posts' ),
	                'screen_reader_text' => __( 'Posts navigation' ),
	            )
	        );

	        $next_link = get_previous_posts_link( $args['next_text'] );
	        $prev_link = get_next_posts_link( $args['prev_text'] );
					$current = max( 1, get_query_var('paged') );

					$navigation .= '<div class="nav-previous">' . $prev_link . '&nbsp;</div>';
					$navigation .= '<div class="nav-pagination">Page ' . $current .' of '. $total .'</div>';
	        $navigation .= '<div class="nav-next">&nbsp;' . $next_link . '</div>';
	        $navigation = _navigation_markup( $navigation, 'posts-navigation', $args['screen_reader_text'] );

	    endif;

	    return $navigation;

	}

endif;


if ( ! function_exists( 'two_eight_sixtyseven_post_thumbnail' ) ) :
	/**
	 * Displays an optional post thumbnail.
	 *
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 */
	function two_eight_sixtyseven_post_thumbnail() {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>

			<div class="post-thumbnail">
				<?php the_post_thumbnail(); ?>
			</div><!-- .post-thumbnail -->

		<?php else : ?>

		<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php
			the_post_thumbnail( 'post-thumbnail', array(
				'alt' => the_title_attribute( array(
					'echo' => false,
				) ),
			) );
			?></a>

		<?php
		endif; // End is_singular().
	}
endif;
