<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package two-eight-sixtyseven
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'two-eight-sixtyseven' ); ?></a>

	<header id="masthead" class="site-header">

		<nav id="site-navigation" class="main-navigation" role="navigation">

			<div class="site-branding right">
	      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
			</div><!-- .site-branding -->

      <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		  <!--<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'two-eight-sixtyseven' ); ?></button>-->
			<?php
			//wp_nav_menu( array(
			//	'theme_location' => 'menu-1',
			//	'menu_id'        => 'primary-menu',
			//) );
			?>
		</nav><!-- #site-navigation -->

    <!--<div class="search-bar">
			<form id="searchform" class="container" method="get" action="<?php echo home_url('/'); ?>">
    		<input type="text" class="search-field" name="s" placeholder="Type and press enter" value="<?php the_search_query(); ?>">
    		<input type="submit" class="screen-reader-text" value="Search">
      </form>
		</div>-->


		<!--mockup navigation-->
		<div id="nav-mobile" class="sidenav hide">
			<div class="sidenav-close"><i class="material-icons">close</i></div>
			
			
			<header>Johannes K. Kalma
<img src="https://johanneskalma.nl/wp-content/uploads/2022/12/johannes_mudmasters.jpg" width="200px" style="display:block;margin:auto;">
</header>

<!-- 
section style="font-size:0.8rem;">
Met de K. van Kornelis<br>
Ik woon samen met  <a href="https://antinebreimer.nl" target="_blank">Antine</a>, ben vader van <a href="https://hannakalma.nl" target="_blank">Hanna</a> en <a href="http://jitzekalma.nl" target="_blank">Jitze</a>.
Al heel lang (te) Oracle plsql ontwikkelaar. Werk sinds 2014 bij <a href="https://www.werkenbijaswatson.nl/" target="_blank">Aswatson Group It Europe</a> als process automation Admininstator / <a href="https://www.redwood.com/" target="_blank">Redwood RunMyJobs</a>Administrator. Java developer.
In mijn vrije tijd ga ik naar de <a href="https://sportcity.nl" target="_blank">Gym</a>, stap op mijn <a href="https://www.strava.com/athletes/6605905" target="_blank">(Race)fiets</a>, bind een plank onder mijn voeten om te <a href="https://youtu.be/tNrP1SXQ-RY" target="_blank">Snowboarden</a>. Maar ben ook heel goed in bank hangen met een afstandsbediening. Nog wat Keywords: Linux, Raspberry Pi, NodeJs <a href="https://youtu.be/iNoERQ8zhoI" target="_blank">Kinderen opvoeden</a>.
</section>
-->
			
	<?php get_sidebar('Sidebar'); ?>		
		</div>
		<!-- mockup end -->

	</header><!-- #masthead -->

	<div id="content" class="site-content container">
