<?php
/**
 * The sidebar containing the footer widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package two-eight-sixtyseven
 */

?>

<div class="widget-area-wrapper">
 	<div id="secondary" class="row widget-area" role="complementary">
 		<div class="col l6 m12 s12"><?php dynamic_sidebar( 'footer-1' ); ?></div>
 		<div class="col l3 m6 s12"><?php dynamic_sidebar( 'footer-2' ); ?></div>
 		<div class="col l3 m6 s12"><?php dynamic_sidebar( 'footer-3' ); ?></div>
 	</div><!-- #secondary -->
</div>
