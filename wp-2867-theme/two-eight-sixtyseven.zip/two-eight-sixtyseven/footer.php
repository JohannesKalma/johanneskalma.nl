<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package two-eight-sixtyseven
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">

    <?php get_sidebar('footer'); ?>

		<div class="site-info">
			<div class="content">
			  <p class="copyright">© 2019 <a href="#">Two Eight Sixtyseven</a></p>
			  <p class="credits">
					      <?php  /* translators: 1: Theme name, 2: Theme author. */
								  printf( esc_html__( 'Theme by %1$s.', 'two-eight-sixtyseven' ), '<a href="http://johanneskalma.nl">Johannes K. Kalma</a>' );
								?>
				</p>
			  <a href="#" title="Go back to the top" class="to-the-top"><span class="fa fw fa-arrow-up"></span></a>
      </div><!-- .content -->
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>


<script>
// script for sidebar. needs to be moved to js file .....
var overlay = document.createElement('div');
overlay.classList.add('sidenav-overlay');
document.body.appendChild(overlay);

var sidebarBtnOpen  = document.getElementsByClassName('sidenav-trigger')[0];
var sidebarBtnClose  = document.getElementsByClassName('sidenav-close')[0];
var sidebarOverlay  = document.getElementsByClassName('sidenav-overlay')[0];
var sidebar         = document.getElementById('nav-mobile');

function openSidebar(){
  sidebar.classList.add("show");
  sidebarOverlay.classList.add("show");
  sidebar.classList.remove("hide");
  sidebarOverlay.classList.remove("hide");
}

function closeSidebar(){
  sidebar.classList.remove("show");
  sidebar.classList.add("hide");
  sidebarOverlay.classList.remove("show");
  sidebarOverlay.classList.add("hide");
}

sidebarBtnOpen.addEventListener('click', openSidebar);
sidebarBtnClose.addEventListener('click', closeSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);
</script>
</body>
</html>
